

%% Inputs

n_elem = [2,4,8,16]; % number of elements in each direction
type_opt = [{'AMC'},{'CR'}]; % options are AMC, CR or shell
l_h_ratio = [100, 10];


%% Define properties

prop.l = 0.5; % length of edge in meters
prop.h = prop.l/l_h_ratio(1); % thickness in meters
prop.E = 210 * 10^9; % elastic modulus in Pa
prop.nu = 0.3; % poisson's ratio (unitless)
prop.rho = 7850; % material density in kg/m^3
prop.k = 5/6; % shear correction coefficient

modeNumber = 1;

%% Find natural frequencies and mode shapes

% create empty arrays to hold outputs
freq_tot_100 = zeros(2,length(n_elem));
mode_shape_tot = cell(2,length(n_elem));
free_nodes_tot = cell(2,length(n_elem));
time_analyze = zeros(2,length(n_elem));

for k = 1:length(type_opt) % cycle through each type of shell elements
        
    type = type_opt{k};
 
    switch type % change number of degrees of freedom for each node depending on type of element used
        case 'AMC'
            DoF = 3; 
        case 'CR'
            DoF = 4;
    end

    for i = 1:length(n_elem) % go through each number of elements to test
        
        tic
    
        [modes,frequencies,free_nodes] = thin_plate(prop,type,n_elem(i)); % calculate frequencies and mode shapes

        % store results and print to command window
        freq_tot_100(k,i) = frequencies(1);
        mode_shape_tot{k,i} = modes(:,modeNumber);
        free_nodes_tot{k,i} = free_nodes;
        text = sprintf('\n First natural frequency is %.4f Hz with n = %i and l/h = %i, element type %s.',frequencies(1), n_elem(i),l_h_ratio(1),type);
        fprintf(text)

        time_analyze(k,i) = toc;
    
    end

end

%% Analytical solution -

% Kirchoff-Love analytical solution
m = 1;
n = 1;
D = prop.E*prop.h^3/(12*(1-prop.nu^2));
freq_an_100 = pi^2*(m^2+n^2)/(prop.l^2)*sqrt(D/(prop.rho*prop.h))/(2*pi); % analytical frequency in Hz

text = sprintf('\n First natural frequency (Analytic - Thin) is %.4f Hz for l/h = %i.',freq_an_100,l_h_ratio(1));
fprintf(text)

% Reissner-Mindlin analytical solution
omega_thick = computeExactFrequency(prop.l, prop.l, prop.h, prop.nu, prop.E, prop.rho, prop.k, 1, 1);
freq_an_thick_100 = omega_thick./(2*pi);

text = sprintf('\n First natural frequency (Analytic - Thick) is %.4f Hz for l/h = %i.',freq_an_thick_100,l_h_ratio(1));
fprintf(text)
%% Plot evolution of first natural frequency

figure()
plot(n_elem,freq_tot_100(1,:),'o-','LineWidth',2)
hold on
plot(n_elem,freq_tot_100(2,:),'o-','LineWidth',2)
yline(freq_an_100,'--','Linewidth',2)
hold off
xlabel('Number of elements (n) per direction','interpreter','latex')
ylabel('1st Natural Frequency (Hz)','interpreter','latex')
title('Convergence of first natural frequnecy','interpreter','latex')
grid on
grid minor
legend('FEM AMC $f_n$','FEM CR $f_n$','Analytic $f_n$ = 98.343 Hz','location','southeast','interpreter','latex')
set(gca,'fontsize',16)
set(gca,'TickLabelInterpreter','latex')

figure()
loglog(n_elem,abs(freq_tot_100(1,:)-freq_an_100),'o-','LineWidth',2)
hold on
loglog(n_elem,abs(freq_tot_100(2,:)-freq_an_100),'o-','LineWidth',2)
hold off
xlabel('Number of elements (n) per direction')
ylabel('ln of 1st Natural Frequency Error (Hz)')
%set(gca, 'YScale', 'log');
title('Convergence of first natural frequnecy')
legend('AMC elements','CR elements')
grid on
grid minor

figure()
plot(n_elem,abs(freq_tot_100(1,:)-freq_an_100),'o-','LineWidth',2)
hold on
plot(n_elem,abs(freq_tot_100(2,:)-freq_an_100),'o-','LineWidth',2)
hold off
xlabel('Number of elements (n) per direction')
ylabel('1st Natural Frequency Error (Hz)')
title('Convergence of first natural frequnecy')
legend('AMC elements','CR elements')
grid on
grid minor


%% Plot Mode Shapes

for k = 1:length(type_opt) % go through each type of element used

    type = type_opt{k};

    switch type
        case 'AMC'
            DoF = 3; % number of degrees of freedom for each node
        case 'CR'
            DoF = 4;
    end


    for i = 1:length(n_elem) % go through each number of elements tested
        modes = mode_shape_tot{k,i};
        scale = prop.l/2; % what do you want the max height of the plot to bo
    
    
        % Get out coordinates
        n_elem_q = n_elem(i)./2; % number of elements in quarter of plate in each direction
        n_nodes_q = (n_elem_q+1)^2; % total number of nodes in quarter of plate
        n_elem_q_tot = n_elem_q^2; % total number of elements in quarter of plate
        
        x_base = linspace(0,prop.l/2,n_elem_q+1); 
        y_base = linspace(0,prop.l/2,n_elem_q+1); 
        
        nodes_x = zeros(n_nodes_q,1);
        nodes_y = zeros(n_nodes_q,1);
        
        old = 1;
        for j = 1 : n_nodes_q/(n_elem_q+1)
            nodes_x(old:j*(n_elem_q+1)) = x_base;
            nodes_y(old:j*(n_elem_q+1)) = y_base(j);
            old = j*(n_elem_q+1) + 1;
        end
    
        quartplotMode(modeNumber,modes,DoF,n_nodes_q,nodes_x,nodes_y,scale,free_nodes_tot{k,i},n_elem_q, type)
    
    end
end

%% Look at what happens when the span/thickness ratio is changed

prop.h = prop.l/l_h_ratio(2); % thickness in meters

freq_tot_10 = zeros(2,length(n_elem));

for k = 1:length(type_opt) % go through each type of element

    type = type_opt{k};

    switch type
        case 'AMC'
            DoF = 3; % number of degrees of freedom for each node
        case 'CR'
            DoF = 4;
    end

    for i = 1:length(n_elem) % go through each number of elements to test
    
        [modes,frequencies,free_nodes] = thin_plate(prop,type,n_elem(i));
        freq_tot_10(k,i) = frequencies(1);
        text = sprintf('\n First natural frequency is %.4f Hz with n = %i, l/h = %i, and element type %s.',frequencies(1), n_elem(i),l_h_ratio(2), type);
        fprintf(text)
    
    end
end

% Analytical solution (Kirchoff-Love)

m = 1;
n = 1;
D = prop.E*prop.h^3/(12*(1-prop.nu^2));
freq_an_10 = pi^2*(m^2+n^2)/(prop.l^2)*sqrt(D/(prop.rho*prop.h))/(2*pi); % analytical frequency in Hz
text = sprintf('\n First natural frequency (Analytic) is %.4f Hz for l/h = %i.',freq_an_10,l_h_ratio(2));
fprintf(text)

% Thick plate solution (Reissner-Mindlin)
omega_thick = computeExactFrequency(prop.l, prop.l, prop.l/l_h_ratio(2), prop.nu, prop.E, prop.rho, prop.k, 1, 1);
freq_thick_10 = omega_thick./(2*pi);
text = sprintf('\n First natural frequency (Thick Plate) is %.4f Hz for l/h = %i.',freq_thick_10,l_h_ratio(2));
fprintf(text)

% Plot differences between l/h = 10 and l/h = 100

figure()
plot(n_elem,abs(freq_tot_100(1,:)-freq_an_100)./freq_an_100,'o-','LineWidth',2)
hold on
plot(n_elem,abs(freq_tot_100(2,:)-freq_an_100)./freq_an_100,'o-','LineWidth',2)
plot(n_elem,abs(freq_tot_10(1,:)-freq_an_10)./freq_an_10,'o-','LineWidth',2)
plot(n_elem,abs(freq_tot_10(2,:)-freq_an_10)./freq_an_10,'o-','LineWidth',2)
hold off
xlabel('Number of elements (n) per direction')
ylabel('Normalized 1st Natural Frequency Error')
title('Convergence of first natural frequnecy')
grid on
grid minor
legend('FEM AMC with l/h = 100','FEM CR with l/h = 100','FEM AMC with l/h = 10','FEM CR with l/h = 10','location','northeast')


%% Look at many different h's

h_tot = 0.005:0.005:0.1;
m = 1;
n = 1;

freq_thin = zeros(length(h_tot),1);
freq_thick = zeros(length(h_tot),1);
freq_CR = zeros(length(h_tot),1);
freq_AMC = zeros(length(h_tot),1);

for i=1:length(h_tot) % go through different plate thicknesses

    h=h_tot(i);

    D = prop.E*h^3/(12*(1-prop.nu^2));
    freq_thin(i) = pi^2*(m^2+n^2)/(prop.l^2)*sqrt(D/(prop.rho*h))/(2*pi); % analytical frequency in Hz based on Kirchoff-Love
    
    omega_thick = computeExactFrequency(prop.l, prop.l, h, prop.nu, prop.E, prop.rho, prop.k, 1, 1);
    freq_thick(i) = omega_thick./(2*pi); % analytical frequency in Hz based on Reissner-Mindlin

    prop.h = h;
end

figure()
plot(h_tot,freq_thin,'-o','Linewidth',2)
hold on
plot(h_tot,freq_thick,'-o','Linewidth',2)
hold off
grid on
xlabel('$h [m]$', 'Interpreter', 'latex', 'fontsize', 14)
ylabel('Natural frequency (Hz)', 'Interpreter', 'latex', 'fontsize', 14)
legend('Thin Plate','Thick Plate', 'Interpreter', 'latex', 'fontsize', 14)
set(gca,'fontsize',16)
set(gca,'TickLabelInterpreter','latex')

figure()
plot(prop.l./h_tot,freq_thin,'-o','Linewidth',2)
hold on
plot(prop.l./h_tot,freq_thick,'-o','Linewidth',2)
hold off
grid on
xlabel('$l/h$', 'Interpreter', 'latex', 'fontsize', 14)
ylabel('Natural frequency (Hz)', 'Interpreter', 'latex', 'fontsize', 14)
legend('Thin Plate','Thick Plate', 'Interpreter', 'latex', 'fontsize', 14)
set(gca,'fontsize',16)
set(gca,'TickLabelInterpreter','latex')

figure()
plot(h_tot,abs(freq_thin-freq_thick)./freq_thick*100,'-o','Linewidth',2)
grid on
xlabel('$h [m]$', 'Interpreter', 'latex', 'fontsize', 14)
ylabel('Normalized Error of thin plate (\%)', 'Interpreter', 'latex', 'fontsize', 14)
set(gca,'fontsize',16)
set(gca,'TickLabelInterpreter','latex')

figure()
plot(prop.l./h_tot,abs(freq_thin-freq_thick)./freq_thick*100,'-o','Linewidth',2)
grid on
xlabel('$l/h [m]$', 'Interpreter', 'latex', 'fontsize', 14)
ylabel('Normalized Error of thin plate (\%)', 'Interpreter', 'latex', 'fontsize', 14)
yline(1,'--','Linewidth',2)
set(gca,'fontsize',16)
set(gca,'TickLabelInterpreter','latex')