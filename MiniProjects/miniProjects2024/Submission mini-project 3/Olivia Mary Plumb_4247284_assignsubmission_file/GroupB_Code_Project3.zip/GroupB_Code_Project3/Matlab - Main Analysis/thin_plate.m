function [modes,frequencies,indices_free_nodes] = thin_plate(prop,type,n_elem)
%thin_plate uses Kirchoff-love FEM analysis to find natural frequencies and
%mode shapes of plate
%   prop is a function containing geometric and material properties of
%   plate
%   type is a string indicating whether AMC or CR elements are to be used
%   n_elem is how many elements in each direction to use

%% Define properties

l = prop.l; % length of edge in meters
h = prop.h; % thickness in meters
E = prop.E; % elastic modulus in Pa
nu = prop.nu; % poisson's ratio (unitless)
rho = prop.rho; % material density in kg/m^3

switch type
    case 'AMC'
        DoF = 3; % number of degrees of freedom for each node
    case 'CR'
        DoF = 4;
end

%% Find stiffness matrix C
% source: https://en.wikipedia.org/wiki/Kirchhoff%E2%80%93Love_plate_theory
% this is for in-plane only stress

% other source: https://en.wikipedia.org/wiki/Hooke%27s_law

C = E/(1-nu^2)*[1,nu,0;nu,1,0;0,0,(1-nu)/2];


%% Get out nodes/element information

% we will just look at a quarter of the plate

n_elem_q = n_elem./2; % number of elements in quarter of plate in each direction
n_nodes_q = (n_elem_q+1)^2; % total number of nodes in quarter of plate
n_elem_q_tot = n_elem_q^2; % total number of elements in quarter of plate

b = l / 2 / n_elem; % half of element height
a = l / 2 / n_elem; % half of element width


%% Find H and B Matrices

% coordinates in archetypal element
eta_1_act = [-1 1 1 -1];
eta_2_act = [-1 -1 1 1];

% empty matrix to store shape functions
H = sym(zeros(1,DoF*4));

syms eta_1 eta_2 eta eta_i


switch type
    case 'AMC'
        for j = 1 : 4 % % AMC elements have 4 nodes per element
        
            % find local coordinates of node j
            eta_1_loc = eta_1_act(j);
            eta_2_loc = eta_2_act(j);
        
         
            % create shape functions
            H((j-1)*3+1) = (1+eta_1_loc*eta_1)*(1+eta_2*eta_2_loc)*(2+eta_1*eta_1_loc+eta_2*eta_2_loc-eta_1^2-eta_2^2)/8;
            H((j-1)*3+2) = b*(1+eta_1*eta_1_loc)*(eta_2+eta_2_loc)*(eta_2^2-1)/8;
            H((j-1)*3+3) = -a*(eta_1_loc+eta_1)*(eta_1^2-1)*(1+eta_2*eta_2_loc)/8;
        end

    case 'CR'
        %create shape functions
        f = (-eta_i*eta^3+3*eta_i*eta+2)/4;
        g = (eta^3+eta_i*eta^2-eta-eta_i)/4;
        for j = 1:4 % go through each node, CR elements have 4 nodes per element
            eta_1_loc = eta_1_act(j);
            eta_2_loc = eta_2_act(j);

            H((j-1)*4+1) = subs(subs(f,eta,eta_1),eta_i,eta_1_loc)*subs(subs(f,eta,eta_2),eta_i,eta_2_loc);
            H((j-1)*4+2) = b*subs(subs(f,eta,eta_1),eta_i,eta_1_loc)*subs(subs(g,eta,eta_2),eta_i,eta_2_loc);
            H((j-1)*4+3) = -a*subs(subs(g,eta,eta_1),eta_i,eta_1_loc)*subs(subs(f,eta,eta_2),eta_i,eta_2_loc);
            H((j-1)*4+4) = a*b*subs(subs(g,eta,eta_1),eta_i,eta_1_loc)*subs(subs(g,eta,eta_2),eta_i,eta_2_loc);
        end

        
end


% create derivative matrix
B = sym(zeros(3,DoF*4));

B(1,:) = diff(diff(H,eta_1),eta_1)/(a^2);
B(2,:) = diff(diff(H,eta_2),eta_2)/(b^2);
B(3,:) = 2*diff(diff(H,eta_1),eta_2)/(a*b);



%% find elemental K and M matrices
% note: no applied loads, so r = 0

e_K = (h)^3*a*b/12*int(int(transpose(B)*C*B,eta_1,[-1,1]),eta_2,[-1,1]);
e_M = rho*(h)*a*b*int(int(transpose(H)*H,eta_1,[-1,1]),eta_2,[-1 1]);


%% create Connectivity Matrix

connectivity = cell(1, n_elem_q_tot); 

row = 1;
for i = 1:n_elem_q_tot
    connectivity{i} = [i + (row-1), i + row, i + row + n_elem_q + 1, i + row + n_elem_q];
    if mod(i,n_elem_q) == 0
        row = row+1;
    end
end


%% Get global K and M 

% for AMC elements, each node has 3 DoF (example: Node 1 has DoF 1 - 3, and node 2 has DoF 4
% - 6)

% for CR elements, each node has 4 DoF (example: Node 1 has DoF 1 - 4, and
% node 2 has DoF 5
% - 8)

K_global = zeros(n_nodes_q*DoF);
M_global = zeros(n_nodes_q*DoF);

for e = 1:n_elem_q_tot

    indices = (connectivity{e}-1)*DoF+1;
    global_indices = zeros(1,length(indices)*DoF);

    for i = 1:length(indices)
        idx = indices(i);
        global_indices(((i-1)*DoF+1):((i-1)*DoF+DoF)) =  idx:(idx+DoF-1);
    end
    
    K_global(global_indices,global_indices) = K_global(global_indices,global_indices) + e_K;
    M_global(global_indices,global_indices) = M_global(global_indices,global_indices) + e_M;

end

%% Boundary conditions (set constrained nodes)

% bottom edge constrains u3 and theta_2
% left edge constrains u3 and theta_1

% For symmetric modes:
    % right side constrains theta_2 (and theta_12 for CR elements)
    % top side constrains theta_1 (and theta_12 for CR elements)

% We are only looking at first mode shape, which is always 
% symmetric for a simply supported plate

% in global numbering system
bottom_nodes = 1:(n_elem_q+1);
left_nodes = 1:(n_elem_q+1):(n_nodes_q-n_elem_q);
right_nodes = (n_elem_q+1):(n_elem_q+1):n_nodes_q; 
top_nodes = (n_nodes_q-n_elem_q):n_nodes_q;

constrained_nodes = [];

for i = 1:length(bottom_nodes)
    node = bottom_nodes(i);
    global_indices = ((node - 1)*DoF+1):((node - 1)*DoF+DoF);
    constrained_nodes = [constrained_nodes, global_indices([1,3])];
end

for i = 1:length(left_nodes)
    node = left_nodes(i);
    global_indices = ((node - 1)*DoF+1):((node - 1)*DoF+DoF);
    constrained_nodes = [constrained_nodes, global_indices([1,2])];
end

for i = 1:length(right_nodes)
    node = right_nodes(i);
    global_indices = ((node - 1)*DoF+1):((node - 1)*DoF+DoF);
    constrained_nodes = [constrained_nodes, global_indices(3)];

    switch type
        case 'CR'
            constrained_nodes = [constrained_nodes, global_indices(4)];
    end
end

for i = 1:length(top_nodes)
    node = top_nodes(i);
    global_indices = ((node - 1)*DoF+1):((node - 1)*DoF+DoF);
    constrained_nodes = [constrained_nodes, global_indices(2)];

    switch type
        case 'CR'
            constrained_nodes = [constrained_nodes, global_indices(4)];
    end
end

constrained_nodes = unique(constrained_nodes); % get rid of repeats

%% Find reduced Global K and M matrices

indices_free_nodes = setdiff((1:(n_nodes_q*DoF))',constrained_nodes);

K_global_free_nodes = K_global(indices_free_nodes, indices_free_nodes);
M_global_free_nodes = M_global(indices_free_nodes, indices_free_nodes);

%% Find natural frequencies and mode shapes by solving eigenvalue problem

[modes,D] = eig(K_global_free_nodes,M_global_free_nodes);
eigenvalues = diag(D);
omega = sqrt(eigenvalues);
frequencies = omega./(2*pi);

end