function  quartplotMode(modeNumber,modes,DoF,n_nodes_q,nodes_x,nodes_y,scale,indices_free_nodes,n_elem_q,type)
%quartplotMode takes in mode shape information for a quarter of the plate
%and plots the resulting displacement for the entire plate
%   modeNumber is which frequency to look at
%   modes is a matrix with frequency modes
%   DoF is how many degrees of freedom each node has
%   n_nodes_q is total number of nodes in a quarter of the plate
%   nodes_x and nodes_y are the x and y coordinates of all nodes (vector)
%   scale is the factor by which you want to scale the displacements
%   indices_free_nodes are the global indices of free DoF in quarter plate
%   n_elem_q is the number of elements in quarter of plate in each direction
%   type is the kind of elements being used (just for title string)

% plot first mode shape
mode_shape = modes(:, modeNumber);

displacements_tot = zeros(1,n_nodes_q*DoF);
displacements_tot(indices_free_nodes) = mode_shape;

% Extract displacements in the x, y, and rotation directions
displacements_u = displacements_tot(1:DoF:end);
rotations_theta1 = displacements_tot(2:DoF:end);
rotations_theta2 = displacements_tot(3:DoF:end);

scale_act = scale/max(abs(displacements_u));

u_out = displacements_tot(1:DoF:end);
u_plot = zeros(length(unique(nodes_x)));

if max(u_out)>abs(min(u_out))
    u_out = -1*u_out;
end

for i = 1:length(unique(nodes_x))
    u_plot(i,:) = u_out((i-1)*(n_elem_q+1)+1:(i-1)*(n_elem_q+1)+1+n_elem_q);
end

% make plots the same direction
if max(max(u_plot)) > abs(min(min(u_plot)))
    color = jet;
else
    color = flipud(jet);
end

% Since we only looked at a quarter of the plate, perform mirroring to get
% the entire image

x_coord = unique(nodes_x)';
nodes_x_tot = [x_coord, x_coord(end)+x_coord(2:end)];

y_coord = unique(nodes_y)';
nodes_y_tot = [y_coord, y_coord(end)+y_coord(2:end)];

[X,Y] = meshgrid(nodes_x_tot,nodes_y_tot);

left_u_plot = [u_plot; u_plot(end-1:-1:1,:)];
tot_u_plot = [left_u_plot, left_u_plot(:,end-1:-1:1)];


% Create a surface plot for the displacement in the x direction
figure();
surf(X, Y, tot_u_plot*scale_act);  % Surface plot for x displacement
colormap(color);
xlabel('x (m)');
ylabel('y (m)');
zlabel('Displacement in z (m)');
str_title = sprintf('First Mode Shape for n = %i, and %s element type',n_elem_q*2,type);
title(str_title);
shading interp;
colorbar;
axis equal;

end