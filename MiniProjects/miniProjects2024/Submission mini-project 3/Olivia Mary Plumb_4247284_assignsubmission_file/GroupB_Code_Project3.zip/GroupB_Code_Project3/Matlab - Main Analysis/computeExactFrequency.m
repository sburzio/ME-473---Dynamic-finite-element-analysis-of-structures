function omega_exact = computeExactFrequency(length_X, length_Y, h, nu, E, rho, k, n, m)
    % Computes the exact natural frequency of indices n m 
    % for a plate using given parameters.
    % Shear modulus
    G = E / (2 * (1 + nu));
    % Flexural rigidity
    D = E * h^3 / (12 * (1 - nu^2));
    % Wavenumbers
    alpha = m * pi / length_X;
    beta = n * pi / length_Y;
    
    % Matrix of flexural rigidities
    D11 = D;
    D12 = D * nu;
    D22 = D;
    D66 = D * (1 - nu)/2;
    % Matrix of shear rigidities
    S44 = h * k * G;
    S55 = h * k * G;
    % Terms computation
    P11 = D11 * alpha^2 + D66 * beta^2 + S55;
    P12 = (D12 + D66) * alpha * beta;
    P13 = S55 * alpha;
    P22 = D66 * alpha^2 + D22 * beta^2 + S44;
    P23 = S44 * beta;
    P33 = S55 * alpha^2 + S44 * beta^2;
    % Intermediate determinant
    Q = P11 * P22 - P12^2;
    % Frequency squared
    omega_squared = (Q * P33 + 2 * P12 * P23 * P13 - P22 * P13^2 - P11 * P23^2) / (rho * h * Q);
    % Natural frequency
    omega_exact = sqrt(omega_squared);
end