clear
close all
clc

% Dashboard
n = 2; % Try n = 2, 4, 8, ... <--------------------------------------------

mode = 0; % 0: symmetric modes, 1: antisymmetric modes

modeShape = 1; % Choose 1 to 10

%% PARAMETERS
L = 0.25;              % Half plate length (m)
h = 0.005;            % Thickness (m)
E = 210e9;            % Young's modulus (Pa)
nu = 0.3;             % Poisson's ratio
rho = 7850;           % Density (kg/m^3)
D = E*h^3 / (12*(1 - nu^2)); % Flexural rigidity (Pa*m^3)

%% Generate Mesh
function [nodes, elements] = generateMesh(n, L)
    dx = L / n;
    [X, Y] = meshgrid(0:dx:L, 0:dx:L);
    %Y = flipud(Y);
    nodes = [Y(:), X(:)]; % node numbering left->right, bottom->top
    
    elements = zeros(n^2, 4);
    elem = 1;
    for j = 1:n
        for i = 1:n
            n1 = (j-1)*(n+1) + i;
            n2 = n1 + 1;
            n3 = n2 + (n+1);
            n4 = n1 + (n+1);
            elements(elem, :) = [n1, n2, n3, n4]; % CCW
            elem = elem + 1;
        end
    end
end

%% Compute H
function H = computeH(xi, a, b)
    H = zeros(1, 16);
    xi1 = xi(1);
    xi2 = xi(2);

    xi_nodes = [-1, -1; 1, -1; 1, 1; -1, 1];

    for i = 1:4 % node 1 to node 4
        xi1i = xi_nodes(i,1);
        xi2i = xi_nodes(i,2);
        fi1 = (-xi1i*xi1^3 + 3*xi1i*xi1 + 2)/4;
        gi1 = (xi1^3 + xi1i*xi1^2 - xi1 - xi1i)/4;
        fi2 = (-xi2i*xi2^3 + 3*xi2i*xi2 + 2)/4;
        gi2 = (xi2^3 + xi2i*xi2^2 - xi2 - xi2i)/4;

        H(1,((4*(i-1)+1):(4*(i-1)+4))) = [fi1*fi2, b*fi1*gi2, -a*gi1*fi2, a*b*gi1*gi2];
    end
end

%% Compute B
function B = computeB(H_i_j, xi_val)
    syms xi1 xi2 real

    % Evaluate shape function second derivatives using the Hessian
    xi1_val = xi_val(1);
    xi2_val = xi_val(2);

    B = double(subs(H_i_j, {xi1, xi2}, {xi1_val, xi2_val}));
end

%% Compute Element Matrices
function eM = computeElementM(rho, h, a, b)
    % 4x4 Gauss integration (16 points)
    gp = [-0.8611363116, -0.3399810436, ...
           0.3399810436,  0.8611363116];
    w  = [ 0.3478548451,  0.6521451549, ...
           0.6521451549,  0.3478548451];

    eM = zeros(16, 16);

    index = 0;
    for i = 1:4
        for j = 1:4
            index = index + 1;
            xi = [gp(i), gp(j)];
            H = computeH(xi, a, b);
            eM = eM + w(i)*w(j) * (H' * H);
            fprintf('Compute H (%d/16): OK\n', index);
        end
    end

    eM = rho * h * a * b * eM;

    eM = (eM + eM')/2; % <------------ Forces symmetric matrix

    fprintf('Compute eM: OK\n')
end

function eK = computeElementK(E, nu, h, a, b)
    C = E / (1 - nu^2) * ...
        [1, nu, 0;
         nu, 1, 0;
         0, 0, (1 - nu)/2];
    
    % 4x4 Gauss integration (16 points)
    gp = [-0.8611363116, -0.3399810436, ...
           0.3399810436,  0.8611363116];
    w  = [ 0.3478548451,  0.6521451549, ...
           0.6521451549,  0.3478548451];

    eK = zeros(16, 16);

    % Compute Hessian to be evaluated

    syms xi1 xi2 real
    xi_nodes = [-1, -1; 1, -1; 1, 1; -1, 1];

    H = sym(zeros(1, 16));  % shape functions
    Bsym = sym(zeros(3,16));

    for i = 1:4
        xi1i = xi_nodes(i,1);
        xi2i = xi_nodes(i,2);
        fi1 = (-xi1i*xi1^3 + 3*xi1i*xi1 + 2)/4;
        gi1 = (xi1^3 + xi1i*xi1^2 - xi1 - xi1i)/4;
        fi2 = (-xi2i*xi2^3 + 3*xi2i*xi2 + 2)/4;
        gi2 = (xi2^3 + xi2i*xi2^2 - xi2 - xi2i)/4;

        H(1,(4*(i-1)+1):(4*(i-1)+4)) = [fi1*fi2, b*fi1*gi2, -a*gi1*fi2, a*b*gi1*gi2];
    end

    Bsym(1,:) = diff(diff(H, xi1), xi1)/(a^2);
    Bsym(2,:) = diff(diff(H, xi2), xi2)/(b^2);
    Bsym(3,:) = 2*diff(diff(H, xi1), xi2)/(a*b);

    index = 0;
    for i = 1:4
        for j = 1:4
            index = index + 1;
            xi = [gp(i), gp(j)];
            B = computeB(Bsym, xi);
            eK = eK + w(i)*w(j) * (B' * C * B);
            fprintf('Compute B (%d/16): OK\n', index);
        end
    end

    eK = h^3 * a * b / 12 * eK;

    eK = (eK + eK')/2; % <-------- Forces symmetric matrix

    fprintf('Compute eK: OK\n')
end

%% Assemble System
function [M, K, freeDofs] = assemble(n, L, E, nu, rho, h, mode)
    tStart = tic;
    [nodes, elements] = generateMesh(n, L);
    t_mesh = toc(tStart);
    fprintf('Mesh generation: OK\n');

    nNodes = size(nodes, 1);
    nDof = nNodes * 4;

    M = zeros(nDof, nDof);
    K = zeros(nDof, nDof);

    a = L / (2*n);
    b = L / (2*n);

    tStart = tic;
    eM = computeElementM(rho, h, a, b);
    t_eM = toc(tStart);

    tStart = tic;
    eK = computeElementK(E, nu, h, a, b);
    t_eK = toc(tStart);

    tStart = tic;
    for e = 1:size(elements, 1)
        nodeIds = elements(e, :);
        dofIds = reshape([4*nodeIds-3; 4*nodeIds-2; 4*nodeIds-1; 4*nodeIds], 1, []);
        M(dofIds, dofIds) = M(dofIds, dofIds) + eM;
        K(dofIds, dofIds) = K(dofIds, dofIds) + eK;
    end
    t_assembly = toc(tStart);

    tStart = tic;
    bottomNodes = find(abs(nodes(:,2)) == 0); % y=0
    leftNodes = find(abs(nodes(:,1)) == 0); % x = 0
    rightNodes = find(abs(nodes(:,1)) == L); % x = L
    topNodes = find(abs(nodes(:,2)) == L); % y = L

    % SIMPLY SUPPORTED
    fixed_u3 = union(4*bottomNodes - 3, 4*leftNodes - 3);
    fixed_theta1 = 4*leftNodes - 2;
    fixed_theta2 = 4*bottomNodes - 1;

    if mode == 1
        % ASYMMETRIC MODES
        fixed_u3 = union(fixed_u3, 4*rightNodes - 3);
        fixed_u3 = union(fixed_u3, 4*topNodes - 3);
        fixed_theta1 = union(fixed_theta1, 4*rightNodes - 2);
        fixed_theta2 = union(fixed_theta2, 4*topNodes - 1);

        % Combine all fixed DOFs
        fixedDofs = [fixed_u3', fixed_theta1', fixed_theta2'];
    else
        % SYMMETRIC MODES
        fixed_theta1 = union(fixed_theta1, 4*topNodes - 2);     % Enforce symmetry in x (top edge)
        fixed_theta2 = union(fixed_theta2, 4*rightNodes - 1);   % Enforce symmetry in y (right edge)
        fixed_theta12 = union(4*topNodes, 4*rightNodes);        % theta12 DOF index = 4i

        % Combine all fixed DOFs
        fixedDofs = [fixed_u3', fixed_theta1', fixed_theta2', fixed_theta12'];
    end

    freeDofs = setdiff(1:nDof, fixedDofs);

    M = M(freeDofs, freeDofs);
    K = K(freeDofs, freeDofs);
    t_BC = toc(tStart);

    fprintf('Assembly: OK\n')
    fprintf('[TIME] Mesh: %.2f ms, eM: %.2f ms, eK: %.2f ms, assembly: %.2f ms, BC: %.2f ms, total: %.2f s\n', 1000*t_mesh, 1000*t_eM, 1000*t_eK, 1000*t_assembly, 1000*t_BC, (t_mesh+t_eM+t_eK+t_assembly+t_BC))
end

%% Run Analysis

[M, K, freeDofs] = assemble(n, L, E, nu, rho, h, mode);

[phi, omega2] = eigs(K, M, 10, 'SM'); % Smallest magnitude
omega = sqrt(diag(omega2));
f = omega / (2*pi);
f_min = min(f);

disp(['Minimum natural frequency (Hz): ', num2str(f_min)]);

%% Exact frequencies of a simply supported plate on its four edges
w_exact = zeros(3,3);
for i=1:3
    for j=1:3
        w_exact(i,j) = pi^2/(2*L)^2*(i^2 + j^2)*sqrt(D/(rho*h));
    end
end
f_exact = w_exact./(2*pi);

%% Visualize Mode Shape
% Reconstruct full mesh
[nodes, ~] = generateMesh(n, L);
nNodes = size(nodes, 1);

% Rebuild full mode shape vector (insert zeros at constrained DOFs)
nDof = 4 * nNodes;
full_phi = zeros(nDof, 1);
full_phi(freeDofs) = phi(:, modeShape);

% Extract transverse displacement (w DOFs)
w_disp = full_phi(1:4:end);

% Reshape into grid
X = reshape(nodes(:,1), n+1, n+1);
Y = reshape(nodes(:,2), n+1, n+1);
W = reshape(w_disp, n+1, n+1)/max(abs(w_disp), [], 'all');

if mode == 1
    % ASYMMETRIC
    % Step 1: Mirror right (bottom-right quarter), excluding duplicate mid-column
    W_right = -flipud(W);            % flip in y (columns)
    X_right = 2*L - flipud(X);       % reflect x across x = L
    Y_right = Y;                     % y stays the same
    
    % Combine bottom half
    W_bottom = [W; W_right(2:end,:)];
    X_bottom = [X; X_right(2:end,:)];
    Y_bottom = [Y; Y_right(2:end,:)];
    
    % Step 2: Mirror top (top half), excluding duplicate mid-row
    W_top = fliplr(-W_bottom(:, 1:end-1));               % flip in x (rows)
    X_top = X_bottom;                                    % x stays the same
    Y_top = 2*L - fliplr(Y_bottom);                      % reflect y across y = L
    
    % Combine full plate
    W_full = [W_bottom, W_top];
    X_full = [X_bottom, X_top(:, 1:end-1)];
    Y_full = [Y_bottom, Y_top(:, 2:end)];

else
    % SYMMETRIC
    % Step 1: Mirror right (bottom-right quarter), excluding duplicate mid-column
    W_right = flipud(W);                     % flip in y (columns)
    X_right = 2*L - flipud(X);               % reflect x across x = L
    Y_right = Y;                             % y stays the same
    
    % Combine bottom half
    W_bottom = [W; W_right(2:end,:)];
    X_bottom = [X; X_right(2:end,:)];
    Y_bottom = [Y; Y_right(2:end,:)];
    
    % Step 2: Mirror top (top half), excluding duplicate mid-row
    W_top = fliplr(W_bottom(:, 1:end-1));               % flip in x (rows)
    X_top = X_bottom;                                   % x stays the same
    Y_top = 2*L - fliplr(Y_bottom);                     % reflect y across y = L
    
    % Combine full plate
    W_full = [W_bottom, W_top];
    X_full = [X_bottom, X_top(:, 1:end-1)];
    Y_full = [Y_bottom, Y_top(:, 2:end)];
end

% Animate Mode Shape
nFrames = 50;
T = 1.5 / f(modeShape);
t = linspace(0, T, nFrames);

figure;
plot3D = surf(X_full, Y_full, zeros(size(W_full)), 'EdgeColor', 'none');
shading interp;
colormap jet;
%colorbar;
xlabel('x (m)');
ylabel('y (m)');
zlabel('w (m)');
xlim([0, 2*L]);
ylim([0, 2*L]);
zlim([-1, 1]*max(abs(W_full(:))));
view(3);
title(['[CR] Animated Mode Shape ', num2str(modeShape), ' (f = ', num2str(f(modeShape)), ' Hz)']);

for k = 1:nFrames
    Z = W_full * cos(2*pi*f(modeShape)*t(k));
    set(plot3D, 'ZData', Z);
    drawnow;
    pause(0.05)
end

%% Mode shape approximation
% Number of interpolation points per element
nInterp = 1000;

% Preallocate
x_vals = [];
w_fem_vals = [];
w_exact_vals = [];
element_x_ranges = {}; % NEW: Store x-ranges for each intersecting element

% Choose centerline: y = L
y_center = L;

% Get original mesh
[nodes, elements] = generateMesh(n, L);

% Full mode shape
full_phi = zeros(4*size(nodes,1),1);
full_phi(freeDofs) = phi(:,modeShape);

% Loop over elements intersecting y = L
for e = 1:size(elements,1)
    nodeIds = elements(e,:);
    coords = nodes(nodeIds,:);

    % Check if element spans y = L
    y_min = min(coords(:,2));
    y_max = max(coords(:,2));
    if y_center < y_min || y_center > y_max
        continue;
    end

    % Store x-range of element for shading
    x_start = min(coords(:,1));
    x_end   = max(coords(:,1));
    element_x_ranges{end+1} = [x_start, x_end]; % NEW

    % Element DOFs
    dofIds = reshape([4*nodeIds-3; 4*nodeIds-2; 4*nodeIds-1; 4*nodeIds], 1, []);
    q_elem = full_phi(dofIds);

    % Element size
    a = (max(coords(:,1)) - min(coords(:,1)))/2;
    b = (max(coords(:,2)) - min(coords(:,2)))/2;

    % Loop over xi1 from -1 to 1, xi2 = 0 (center of element vertically)
    for xi1 = linspace(-1,1,nInterp)
        xi = [xi1, 0];
        H = computeH(xi, a, b);

        H_u3 = H([1,5,9,13]);
        q_u3 = q_elem([1,5,9,13]);

        w_fem = H_u3 * q_u3;

        x_global = ((xi1 + 1)/2)*(coords(2,1) - coords(1,1)) + coords(1,1);

        m = 1; n_ = 1;
        w_exact = sin(m*pi*x_global/(2*L)) * sin(n_*pi*y_center/(2*L));

        x_vals(end+1) = x_global;
        w_fem_vals(end+1) = w_fem;
        w_exact_vals(end+1) = w_exact;
    end
end

% Normalize both for fair comparison
w_fem_vals = w_fem_vals / max(abs(w_fem_vals));
w_exact_vals = w_exact_vals / max(abs(w_exact_vals));

if w_fem_vals(end) < 0
    w_fem_vals = -w_fem_vals;
end

[x_vals_sorted, idx_sort] = sort(x_vals);
w_fem_sorted = w_fem_vals(idx_sort);
w_exact_sorted = w_exact_vals(idx_sort);

% Plot comparison
figure;

% === NEW: Add colored regions for each intersecting element ===
colors = lines(length(element_x_ranges)); % Use distinguishable colors
y_limits = [0, 1]; % Vertical span for shaded patches

for i = 1:length(element_x_ranges)
    x_rng = element_x_ranges{i};
    
    % Find indices in sorted x within this x-range
    in_range = x_vals_sorted >= x_rng(1) & x_vals_sorted <= x_rng(2);
    
    % Skip if no points found (edge case)
    if ~any(in_range), continue; end
    
    % Extract the corresponding x and w values
    x_patch = x_vals_sorted(in_range);
    y_patch = w_fem_sorted(in_range);

    % Build polygon under the curve (add base line to x-axis)
    x_fill = [x_patch, fliplr(x_patch)];
    y_fill = [y_patch, zeros(size(y_patch))];

    fill(x_fill, y_fill, colors(i,:), 'FaceAlpha', 0.2, 'EdgeColor', 'none'); hold on;
end
plot(x_vals_sorted, w_fem_sorted, 'b-', 'LineWidth', 2); hold on;
plot(x_vals_sorted, w_exact_sorted, 'r--', 'LineWidth', 2);

% Dummy plots for legend
p1 = plot(NaN, NaN, 'b-', 'LineWidth', 2);
p2 = plot(NaN, NaN, 'r--', 'LineWidth', 1.5);

xlabel('x [m]', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('$u_3$ [m]', 'Interpreter', 'latex', 'FontSize', 13);
title(sprintf('[CR] n = %d', 2*n), 'Interpreter', 'latex', 'FontSize', 15);
legend([p1, p2], {'FEM Approximation', 'Analytical Shape'}, 'Location', 'northwest', 'Interpreter', 'latex', 'FontSize', 13);
grid on;
ylim(y_limits); % Ensure colored regions stay within visible range
